import React, { useState, useEffect } from 'react';
import { usePocketBase } from './hooks/usePocketBase';
import AuthModal from './components/AuthModal';
import './App.css';

function App() {
  const {
    isAuthenticated,
    user,
    transactions: pbTransactions,
    stats,
    createTransaction: pbCreateTransaction,
    deleteTransaction: pbDeleteTransaction,
    fetchStats,
    logout,
    isLoading: pbLoading
  } = usePocketBase();

  const [activeView, setActiveView] = useState('home');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showTransactionModal, setShowTransactionModal] = useState(false);
  const [formData, setFormData] = useState({
    description: '',
    amount: '',
    type: 'expense',
    category: 'cibo',
    date: new Date().toISOString().split('T')[0]
  });

  // ... resto del codice ...

  // Sincronizza dati locali con PocketBase quando l'utente si autentica
  useEffect(() => {
    if (isAuthenticated && user) {
      // Puoi aggiungere qui la sincronizzazione dei dati locali
      console.log('Utente autenticato:', user.email);
    }
  }, [isAuthenticated, user]);

  // Modifica handleSubmitTransaction per usare PocketBase
  const handleSubmitTransaction = async (e) => {
    e.preventDefault();
    
    const amount = parseFloat(formData.amount);
    if (!formData.description || !formData.amount || isNaN(amount) || amount <= 0) {
      alert('Per favore, compila tutti i campi correttamente.');
      return;
    }

    if (isAuthenticated) {
      // Usa PocketBase
      const result = await pbCreateTransaction({
        Importo: formData.type === 'expense' ? -amount : amount,
        Categoria: formData.category,
        Data: formData.date,
        Intestatario: formData.description
      });

      if (result.success) {
        setShowTransactionModal(false);
        setFormData({
          description: '',
          amount: '',
          type: 'expense',
          category: 'cibo',
          date: new Date().toISOString().split('T')[0]
        });
        fetchStats(); // Aggiorna statistiche
      }
    } else {
      // Usa localStorage (modo vecchio)
      // ... codice esistente ...
    }
  };

  // Modifica renderHomeView per mostrare dati da PocketBase
  const renderHomeView = () => {
    const transactionsToShow = isAuthenticated ? pbTransactions : recentTransactions;
    
    return (
      <main className="app-main">
        {/* Banner autenticazione */}
        {!isAuthenticated && (
          <div className="auth-banner" onClick={() => setShowAuthModal(true)}>
            <div className="auth-banner-content">
              <div className="auth-banner-icon">🔒</div>
              <div className="auth-banner-text">
                <h4>Sincronizza i tuoi dati</h4>
                <p>Accedi per salvare le tue transazioni nel cloud</p>
              </div>
              <button className="auth-banner-btn">Accedi / Registrati</button>
            </div>
          </div>
        )}

        {/* Info utente */}
        {isAuthenticated && user && (
          <div className="user-info">
            <div className="user-avatar-small">
              {user.avatar ? (
                <img src={user.avatar} alt={user.name} />
              ) : (
                <div className="avatar-placeholder">
                  {user.name ? user.name.charAt(0).toUpperCase() : user.email.charAt(0).toUpperCase()}
                </div>
              )}
            </div>
            <div className="user-details">
              <div className="user-name">{user.name || user.email}</div>
              <button className="logout-btn" onClick={logout}>Esci</button>
            </div>
          </div>
        )}

        {/* ... resto del codice ... */}
      </main>
    );
  };

  // Aggiungi gestione autenticazione nel render
  return (
    <div className="app">
      {/* Header con info utente */}
      <header className="app-header">
        <div className="header-top">
          <h1>Budget Tracker {isAuthenticated ? `- ${user?.name?.split(' ')[0] || 'Utente'}` : ''}</h1>
          <div className="user-avatar" onClick={() => isAuthenticated ? logout() : setShowAuthModal(true)}>
            {isAuthenticated && user ? (
              <>
                {user.avatar ? (
                  <img src={user.avatar} alt={user.name} className="avatar-icon" />
                ) : (
                  <div className="avatar-icon">
                    {user.name ? user.name.charAt(0).toUpperCase() : user.email.charAt(0).toUpperCase()}
                  </div>
                )}
              </>
            ) : (
              <div className="avatar-icon">👤</div>
            )}
          </div>
        </div>
        
        {/* ... resto del header ... */}
      </header>
      
      {/* ... resto del componente ... */}
      
      {/* Modal autenticazione */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onSuccess={() => {
          // Ricarica dati dopo login
          if (isAuthenticated) {
            // Potresti voler sincronizzare dati locali qui
          }
        }}
      />
      
      {/* ... resto dei modal ... */}
    </div>
  );
}

export default App;