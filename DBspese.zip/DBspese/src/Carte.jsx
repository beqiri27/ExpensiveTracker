import React, { useState } from 'react';
import './App.css';
const Carte = () => {
  // Stato per le carte
  const [carte, setCarte] = useState(() => {
    const saved = localStorage.getItem('budgetTrackerCarte');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return getDefaultCarte();
      }
    }
    return getDefaultCarte();
  });

  // Stato per il modal
  const [showModal, setShowModal] = useState(false);
  
  // Stato per il form
  const [formData, setFormData] = useState({
    nome: '',
    tipo: 'debito',
    numero: '',
    scadenza: '',
    limite: '',
    saldo: '',
    colore: '#6a11cb'
  });

  // Funzione per ottenere carte di default
  function getDefaultCarte() {
    return [
      {
        id: 1,
        nome: "Carta Principale",
        tipo: "credito",
        numero: "**** 1234",
        scadenza: "12/25",
        limite: 5000,
        saldo: 3200,
        spesaMensile: 1800,
        colore: "#6a11cb",
        icona: "💳"
      },
      {
        id: 2,
        nome: "Carta Debito",
        tipo: "debito",
        numero: "**** 5678",
        scadenza: "10/26",
        limite: null,
        saldo: 1250,
        spesaMensile: 750,
        colore: "#2575fc",
        icona: "💳"
      },
      {
        id: 3,
        nome: "Carta Shopping",
        tipo: "credito",
        numero: "**** 9012",
        scadenza: "03/25",
        limite: 2000,
        saldo: 500,
        spesaMensile: 1500,
        colore: "#FF6B8B",
        icona: "🛍️"
      }
    ];
  }

  // Colori disponibili per le carte
  const coloriCarte = [
    { nome: "Viola", valore: "#6a11cb" },
    { nome: "Blu", valore: "#2575fc" },
    { nome: "Rosa", valore: "#FF6B8B" },
    { nome: "Verde", valore: "#4CD964" },
    { nome: "Arancione", valore: "#FF9F43" },
    { nome: "Turchese", valore: "#36BDC1" }
  ];

  // Icone disponibili per le carte
  const iconeCarte = [
    { icona: "💳", nome: "Carta standard" },
    { icona: "🛍️", nome: "Shopping" },
    { icona: "✈️", nome: "Viaggi" },
    { icona: "⛽", nome: "Carburante" },
    { icona: "🏦", nome: "Banca" },
    { icona: "💰", nome: "Risparmi" }
  ];

  // Salva le carte nel localStorage
  React.useEffect(() => {
    try {
      localStorage.setItem('budgetTrackerCarte', JSON.stringify(carte));
    } catch (error) {
      console.error('Errore nel salvataggio nel localStorage:', error);
    }
  }, [carte]);

  // Formatta la valuta
  const formatCurrency = (amount) => {
    const num = Number(amount) || 0;
    return `€${num.toFixed(2)}`;
  };

  // Calcola il totale delle spese mensili
  const calcolaSpesaTotale = () => {
    return carte.reduce((totale, carta) => totale + (carta.spesaMensile || 0), 0);
  };

  // Calcola il saldo totale disponibile
  const calcolaSaldoTotale = () => {
    return carte.reduce((totale, carta) => totale + (carta.saldo || 0), 0);
  };

  // Gestione cambio input
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Gestione cambio colore
  const handleColorChange = (colore) => {
    setFormData(prev => ({
      ...prev,
      colore
    }));
  };

  // Gestione cambio icona
  const handleIconChange = (icona) => {
    setFormData(prev => ({
      ...prev,
      icona
    }));
  };

  // Formatta il numero della carta
  const formattaNumeroCarta = (numero) => {
    if (!numero) return '**** **** **** ****';
    return numero.replace(/(.{4})/g, '$1 ').trim();
  };

  // Gestione submit form
  const handleSubmit = (e) => {
    e.preventDefault();
    
    const limite = formData.tipo === 'credito' ? parseFloat(formData.limite) : null;
    const saldo = parseFloat(formData.saldo) || 0;
    
    if (!formData.nome.trim()) {
      alert('Inserisci un nome per la carta');
      return;
    }
    
    if (formData.tipo === 'credito' && (!limite || limite <= 0)) {
      alert('Per le carte di credito è necessario un limite valido');
      return;
    }
    
    const nuovaCarta = {
      id: carte.length > 0 ? Math.max(...carte.map(c => c.id)) + 1 : 1,
      nome: formData.nome.trim(),
      tipo: formData.tipo,
      numero: formData.numero ? formData.numero.replace(/\s/g, '').slice(-4).padStart(4, '*').padStart(16, '*') : '**** 1234',
      scadenza: formData.scadenza || '12/25',
      limite: limite,
      saldo: saldo,
      spesaMensile: 0,
      colore: formData.colore || '#6a11cb',
      icona: formData.icona || '💳'
    };
    
    setCarte([...carte, nuovaCarta]);
    setShowModal(false);
    setFormData({
      nome: '',
      tipo: 'debito',
      numero: '',
      scadenza: '',
      limite: '',
      saldo: '',
      colore: '#6a11cb',
      icona: '💳'
    });
  };

  // Rimuovi una carta
  const rimuoviCarta = (id) => {
    if (window.confirm('Sei sicuro di voler rimuovere questa carta?')) {
      setCarte(carte.filter(carta => carta.id !== id));
    }
  };

  // Calcola la percentuale di utilizzo per le carte di credito
  const calcolaPercentualeUtilizzo = (carta) => {
    if (carta.tipo !== 'credito' || !carta.limite || carta.limite <= 0) return 0;
    const utilizzato = carta.limite - carta.saldo;
    return Math.round((utilizzato / carta.limite) * 100);
  };

  const spesaTotale = calcolaSpesaTotale();
  const saldoTotale = calcolaSaldoTotale();

  return (
    <div className="app">
      {/* Header */}
      <header className="app-header">
        <div className="header-top">
          <h1>Le mie Carte</h1>
          <div className="user-avatar">
            <div className="avatar-icon">💳</div>
          </div>
        </div>
        
        {/* Statistiche */}
        <div className="balance-container">
          <div className="balance-label">Saldo Totale Carte</div>
          <div className="balance-amount">{formatCurrency(saldoTotale)}</div>
          
          <div className="balance-details">
            <div className="balance-item">
              <div className="balance-item-label">Spesa Mensile</div>
              <div className="balance-item-amount expense">{formatCurrency(spesaTotale)}</div>
            </div>
            <div className="balance-item">
              <div className="balance-item-label">Carte Attive</div>
              <div className="balance-item-amount" style={{ color: '#6a11cb' }}>
                {carte.length}
              </div>
            </div>
          </div>
        </div>
      </header>
      
      {/* Contenuto principale */}
      <main className="app-main">
        {/* Header sezione carte */}
        <div className="section-header" style={{ marginBottom: '20px' }}>
          <h2>Le tue Carte</h2>
          <button className="view-all" onClick={() => setShowModal(true)}>
            + Aggiungi Carta
          </button>
        </div>
        
        {/* Lista carte */}
        <div className="carte-container" style={{ padding: '0 20px' }}>
          {carte.length === 0 ? (
            <div className="no-transactions" style={{ textAlign: 'center', padding: '40px 20px' }}>
              <div style={{ fontSize: '3rem', marginBottom: '20px' }}>💳</div>
              <p>Nessuna carta aggiunta</p>
              <button 
                className="btn-primary" 
                onClick={() => setShowModal(true)}
                style={{ marginTop: '20px', padding: '12px 24px' }}
              >
                Aggiungi la tua prima carta
              </button>
            </div>
          ) : (
            <>
              {carte.map(carta => {
                const percentualeUtilizzo = calcolaPercentualeUtilizzo(carta);
                const isCredito = carta.tipo === 'credito';
                
                return (
                  <div 
                    key={carta.id}
                    className="carta-item"
                    style={{
                      background: `linear-gradient(135deg, ${carta.colore} 0%, ${carta.colore}99 100%)`,
                      color: 'white',
                      borderRadius: '20px',
                      padding: '25px',
                      marginBottom: '20px',
                      boxShadow: '0 10px 20px rgba(0,0,0,0.1)',
                      position: 'relative'
                    }}
                  >
                    <div style={{ 
                      display: 'flex', 
                      justifyContent: 'space-between', 
                      alignItems: 'flex-start',
                      marginBottom: '30px'
                    }}>
                      <div>
                        <div style={{ fontSize: '1.8rem', marginBottom: '10px' }}>
                          {carta.icona}
                        </div>
                        <h3 style={{ margin: '0 0 5px 0', fontSize: '1.4rem' }}>
                          {carta.nome}
                        </h3>
                        <div style={{ opacity: 0.9, fontSize: '0.9rem' }}>
                          {isCredito ? 'Carta di Credito' : 'Carta di Debito'}
                        </div>
                      </div>
                      
                      <button 
                        onClick={() => rimuoviCarta(carta.id)}
                        style={{
                          background: 'rgba(255,255,255,0.2)',
                          border: 'none',
                          color: 'white',
                          width: '40px',
                          height: '40px',
                          borderRadius: '50%',
                          cursor: 'pointer',
                          fontSize: '1.2rem'
                        }}
                      >
                        ×
                      </button>
                    </div>
                    
                    <div style={{ marginBottom: '25px' }}>
                      <div style={{ 
                        fontSize: '1.6rem', 
                        letterSpacing: '2px',
                        marginBottom: '5px'
                      }}>
                        {formattaNumeroCarta(carta.numero)}
                      </div>
                      <div style={{ fontSize: '0.9rem', opacity: 0.8 }}>
                        Scadenza: {carta.scadenza}
                      </div>
                    </div>
                    
                    <div style={{ 
                      display: 'flex', 
                      justifyContent: 'space-between',
                      marginBottom: '15px'
                    }}>
                      <div>
                        <div style={{ fontSize: '0.85rem', opacity: 0.8 }}>
                          {isCredito ? 'Limite' : 'Saldo'}
                        </div>
                        <div style={{ fontSize: '1.3rem', fontWeight: '600' }}>
                          {isCredito ? formatCurrency(carta.limite) : formatCurrency(carta.saldo)}
                        </div>
                      </div>
                      
                      <div>
                        <div style={{ fontSize: '0.85rem', opacity: 0.8 }}>
                          {isCredito ? 'Disponibile' : 'Spesa Mensile'}
                        </div>
                        <div style={{ fontSize: '1.3rem', fontWeight: '600' }}>
                          {isCredito ? formatCurrency(carta.saldo) : formatCurrency(carta.spesaMensile)}
                        </div>
                      </div>
                    </div>
                    
                    {isCredito && (
                      <div>
                        <div style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          marginBottom: '5px',
                          fontSize: '0.85rem'
                        }}>
                          <span>Utilizzo</span>
                          <span>{percentualeUtilizzo}%</span>
                        </div>
                        <div style={{
                          height: '6px',
                          background: 'rgba(255,255,255,0.2)',
                          borderRadius: '3px',
                          overflow: 'hidden'
                        }}>
                          <div style={{
                            height: '100%',
                            width: `${Math.min(percentualeUtilizzo, 100)}%`,
                            background: 'white',
                            borderRadius: '3px'
                          }}></div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </>
          )}
        </div>
        
        {/* Statistiche dettagliate */}
        {carte.length > 0 && (
          <section className="section">
            <div className="section-header">
              <h2>Statistiche Carte</h2>
            </div>
            
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(2, 1fr)',
              gap: '15px',
              padding: '0 20px'
            }}>
              <div className="category-card">
                <div className="category-icon" style={{ color: '#4CD964' }}>
                  💰
                </div>
                <div className="category-details">
                  <div className="category-name">Saldo Totale</div>
                  <div className="category-amount">{formatCurrency(saldoTotale)}</div>
                </div>
              </div>
              
              <div className="category-card">
                <div className="category-icon" style={{ color: '#FF3B30' }}>
                  📊
                </div>
                <div className="category-details">
                  <div className="category-name">Spesa Mensile</div>
                  <div className="category-amount">{formatCurrency(spesaTotale)}</div>
                </div>
              </div>
              
              <div className="category-card">
                <div className="category-icon" style={{ color: '#6a11cb' }}>
                  💳
                </div>
                <div className="category-details">
                  <div className="category-name">Carte Attive</div>
                  <div className="category-amount">{carte.length}</div>
                </div>
              </div>
              
              <div className="category-card">
                <div className="category-icon" style={{ color: '#FF9F43' }}>
                  📈
                </div>
                <div className="category-details">
                  <div className="category-name">Utilizzo Medio</div>
                  <div className="category-amount">
                    {carte.filter(c => c.tipo === 'credito').length > 0 
                      ? Math.round(carte
                          .filter(c => c.tipo === 'credito')
                          .reduce((acc, c) => acc + calcolaPercentualeUtilizzo(c), 0) / 
                        carte.filter(c => c.tipo === 'credito').length)
                      : 0}%
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}
      </main>
      
      {/* Footer e navigazione */}
      <footer className="app-footer">
        <nav className="bottom-nav">
          <button className="nav-item">
            <div className="nav-icon">🏠</div>
            <span>Home</span>
          </button>
          <button className="nav-item">
            <div className="nav-icon">📊</div>
            <span>Statistiche</span>
          </button>
          
          <button className="add-transaction-btn" onClick={() => setShowModal(true)}>
            <div className="nav-icon-add">+</div>
          </button>
          
          <button className="nav-item">
            <div className="nav-icon">🎯</div>
            <span>Obiettivi</span>
          </button>
          <button className="nav-item active">
            <div className="nav-icon">💳</div>
            <span>Carte</span>
          </button>
        </nav>
      </footer>
      
      {/* Modal per aggiungere carte */}
      {showModal && (
        <div className="modal">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Aggiungi Nuova Carta</h3>
              <button className="close-modal" onClick={() => setShowModal(false)}>
                &times;
              </button>
            </div>
            
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="nome">Nome Carta</label>
                <input 
                  type="text" 
                  id="nome" 
                  name="nome"
                  value={formData.nome}
                  onChange={handleInputChange}
                  placeholder="Es. Carta Principale" 
                  required
                />
              </div>
              
              <div className="form-group">
                <label>Tipo Carta</label>
                <div className="type-selector">
                  <button 
                    type="button" 
                    className={`type-btn ${formData.tipo === 'debito' ? 'active' : ''}`}
                    onClick={() => setFormData(prev => ({ ...prev, tipo: 'debito' }))}
                  >
                    Debito
                  </button>
                  <button 
                    type="button" 
                    className={`type-btn ${formData.tipo === 'credito' ? 'active' : ''}`}
                    onClick={() => setFormData(prev => ({ ...prev, tipo: 'credito' }))}
                  >
                    Credito
                  </button>
                </div>
              </div>
              
              {formData.tipo === 'credito' && (
                <div className="form-group">
                  <label htmlFor="limite">Limite di Credito (€)</label>
                  <input 
                    type="number" 
                    id="limite" 
                    name="limite"
                    value={formData.limite}
                    onChange={handleInputChange}
                    step="0.01" 
                    min="0.01" 
                    placeholder="5000.00" 
                    required={formData.tipo === 'credito'}
                  />
                </div>
              )}
              
              <div className="form-group">
                <label htmlFor="saldo">
                  {formData.tipo === 'credito' ? 'Saldo Attuale (€)' : 'Saldo Carta (€)'}
                </label>
                <input 
                  type="number" 
                  id="saldo" 
                  name="saldo"
                  value={formData.saldo}
                  onChange={handleInputChange}
                  step="0.01" 
                  placeholder="0.00" 
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="numero">Ultime 4 cifre (opzionale)</label>
                <input 
                  type="text" 
                  id="numero" 
                  name="numero"
                  value={formData.numero}
                  onChange={handleInputChange}
                  placeholder="1234" 
                  maxLength="4"
                  pattern="[0-9]{4}"
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="scadenza">Scadenza (MM/YY)</label>
                <input 
                  type="text" 
                  id="scadenza" 
                  name="scadenza"
                  value={formData.scadenza}
                  onChange={handleInputChange}
                  placeholder="12/25" 
                  maxLength="5"
                />
              </div>
              
              <div className="form-group">
                <label>Icona Carta</label>
                <div style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '10px',
                  marginTop: '10px'
                }}>
                  {iconeCarte.map((icon, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => handleIconChange(icon.icona)}
                      style={{
                        background: formData.icona === icon.icona ? formData.colore : '#f0f0f0',
                        color: formData.icona === icon.icona ? 'white' : '#333',
                        border: 'none',
                        borderRadius: '10px',
                        width: '50px',
                        height: '50px',
                        fontSize: '1.5rem',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}
                      title={icon.nome}
                    >
                      {icon.icona}
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="form-group">
                <label>Colore Carta</label>
                <div style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '10px',
                  marginTop: '10px'
                }}>
                  {coloriCarte.map((colore, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => handleColorChange(colore.valore)}
                      style={{
                        background: colore.valore,
                        border: `3px solid ${formData.colore === colore.valore ? 'white' : colore.valore}`,
                        borderRadius: '50%',
                        width: '40px',
                        height: '40px',
                        cursor: 'pointer',
                        boxShadow: formData.colore === colore.valore ? '0 0 0 2px #6a11cb' : 'none'
                      }}
                      title={colore.nome}
                    />
                  ))}
                </div>
              </div>
              
              <div className="form-actions">
                <button 
                  type="button" 
                  className="btn-secondary" 
                  onClick={() => setShowModal(false)}
                >
                  Annulla
                </button>
                <button type="submit" className="btn-primary">
                  Aggiungi Carta
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Carte;