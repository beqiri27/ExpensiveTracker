import React, { useState, useEffect } from 'react';
import { usePocketBase } from './Api.js';
import AuthModal from './Api.js';
import './App.css';

function App() {
  const {
    isAuthenticated,
    user,
    transactions: pbTransactions,
    stats,
    createTransaction: pbCreateTransaction,
    deleteTransaction: pbDeleteTransaction,
    createCard: pbCreateCard,
    deleteCard: pbDeleteCard,
    fetchStats,
    logout,
    isLoading: pbLoading
  } = usePocketBase();

  // Stato per la vista attiva
  const [activeView, setActiveView] = useState('home');
  
  // Stato per le transazioni (locale o remote)
  const [transactions, setTransactions] = useState(() => {
    if (isAuthenticated && pbTransactions.length > 0) {
      return pbTransactions;
    }
    const saved = localStorage.getItem('budgetTrackerTransactions');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return getDefaultTransactions();
      }
    }
    return getDefaultTransactions();
  });

  // Stato per le carte
  const [carte, setCarte] = useState(() => {
    const saved = localStorage.getItem('budgetTrackerCarte');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return getDefaultCarte();
      }
    }
    return getDefaultCarte();
  });

  // Modal states
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showTransactionModal, setShowTransactionModal] = useState(false);
  const [showCartaModal, setShowCartaModal] = useState(false);
  
  // Form states
  const [formData, setFormData] = useState({
    description: '',
    amount: '',
    type: 'expense',
    category: 'cibo',
    date: new Date().toISOString().split('T')[0]
  });

  const [cartaFormData, setCartaFormData] = useState({
    nome: '',
    tipo: 'debito',
    numero: '',
    scadenza: '',
    limite: '',
    saldo: '',
    colore: '#6a11cb',
    icona: '💳'
  });

  // Funzioni di default
  function getDefaultTransactions() {
    return [
      {
        id: 1,
        description: "Stipendio",
        amount: 2500,
        type: "income",
        category: "lavoro",
        date: new Date().toISOString().split('T')[0]
      },
      {
        id: 2,
        description: "Supermercato",
        amount: 120,
        type: "expense",
        category: "cibo",
        date: new Date(Date.now() - 86400000).toISOString().split('T')[0]
      },
      {
        id: 3,
        description: "Ristorante",
        amount: 45,
        type: "expense",
        category: "cibo",
        date: new Date(Date.now() - 2 * 86400000).toISOString().split('T')[0]
      }
    ];
  }

  function getDefaultCarte() {
    return [
      {
        id: 1,
        nome: "Carta Principale",
        tipo: "credito",
        numero: "**** 1234",
        scadenza: "12/25",
        limite: 5000,
        saldo: 3200,
        spesaMensile: 1800,
        colore: "#6a11cb",
        icona: "💳"
      },
      {
        id: 2,
        nome: "Carta Debito",
        tipo: "debito",
        numero: "**** 5678",
        scadenza: "10/26",
        limite: null,
        saldo: 1250,
        spesaMensile: 750,
        colore: "#2575fc",
        icona: "💳"
      }
    ];
  }

  // Categorie
  const categories = {
    cibo: { name: "Cibo", icon: "🍕", color: "#FF9F43" },
    trasporti: { name: "Trasporti", icon: "🚗", color: "#36BDC1" },
    casa: { name: "Casa", icon: "🏠", color: "#FF6B8B" },
    lavoro: { name: "Lavoro", icon: "💼", color: "#4CD964" },
    svago: { name: "Svago", icon: "🎬", color: "#9B59B6" },
    salute: { name: "Salute", icon: "⚕️", color: "#3498DB" },
    shopping: { name: "Shopping", icon: "🛍️", color: "#FFCC00" },
    altro: { name: "Altro", icon: "📦", color: "#95A5A6" }
  };

  // Colori disponibili per le carte
  const coloriCarte = [
    { nome: "Viola", valore: "#6a11cb" },
    { nome: "Blu", valore: "#2575fc" },
    { nome: "Rosa", valore: "#FF6B8B" },
    { nome: "Verde", valore: "#4CD964" },
    { nome: "Arancione", valore: "#FF9F43" },
    { nome: "Turchese", valore: "#36BDC1" }
  ];

  // Icone disponibili per le carte
  const iconeCarte = [
    { icona: "💳", nome: "Carta standard" },
    { icona: "🛍️", nome: "Shopping" },
    { icona: "✈️", nome: "Viaggi" },
    { icona: "⛽", nome: "Carburante" },
    { icona: "🏦", nome: "Banca" },
    { icona: "💰", nome: "Risparmi" }
  ];

  // Sincronizza dati quando cambia l'autenticazione
  useEffect(() => {
    if (isAuthenticated && pbTransactions.length > 0) {
      setTransactions(pbTransactions);
    }
  }, [isAuthenticated, pbTransactions]);

  // Salva i dati locali nel localStorage quando non autenticati
  useEffect(() => {
    if (!isAuthenticated) {
      try {
        localStorage.setItem('budgetTrackerTransactions', JSON.stringify(transactions));
        localStorage.setItem('budgetTrackerCarte', JSON.stringify(carte));
      } catch (error) {
        console.error('Errore nel salvataggio nel localStorage:', error);
      }
    }
  }, [transactions, carte, isAuthenticated]);

  // Calcola i totali
  const calculateTotals = () => {
    const transazioniDaUsare = isAuthenticated && pbTransactions.length > 0 ? pbTransactions : transactions;
    
    const income = transazioniDaUsare
      .filter(t => t.type === 'income' || (t.Importo && t.Importo > 0))
      .reduce((sum, t) => sum + (t.amount || Math.abs(t.Importo) || 0), 0);
      
    const expense = transazioniDaUsare
      .filter(t => t.type === 'expense' || (t.Importo && t.Importo < 0))
      .reduce((sum, t) => sum + (t.amount || Math.abs(t.Importo) || 0), 0);
      
    const balance = income - expense;
    
    return { income, expense, balance };
  };

  // Calcola statistiche carte
  const calculateCardStats = () => {
    const spesaTotale = carte.reduce((totale, carta) => totale + (carta.spesaMensile || 0), 0);
    const saldoTotale = carte.reduce((totale, carta) => totale + (carta.saldo || 0), 0);
    const carteAttive = carte.length;
    
    return { spesaTotale, saldoTotale, carteAttive };
  };

  // Formatta la valuta
  const formatCurrency = (amount) => {
    const num = Number(amount) || 0;
    return `€${num.toFixed(2)}`;
  };

  // Formatta la data
  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        return "Data non valida";
      }
      return date.toLocaleDateString('it-IT', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      });
    } catch (error) {
      return "Data non valida";
    }
  };

  // Gestione cambio input transazioni
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Gestione cambio input carte
  const handleCartaInputChange = (e) => {
    const { name, value } = e.target;
    setCartaFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Gestione cambio colore carta
  const handleColorChange = (colore) => {
    setCartaFormData(prev => ({
      ...prev,
      colore
    }));
  };

  // Gestione cambio icona carta
  const handleIconChange = (icona) => {
    setCartaFormData(prev => ({
      ...prev,
      icona
    }));
  };

  // Gestione submit form transazioni
  const handleSubmitTransaction = async (e) => {
    e.preventDefault();
    
    const amount = parseFloat(formData.amount);
    if (!formData.description || !formData.amount || isNaN(amount) || amount <= 0) {
      alert('Per favore, compila tutti i campi correttamente.');
      return;
    }

    if (isAuthenticated) {
      // Usa PocketBase
      const result = await pbCreateTransaction({
        Importo: formData.type === 'expense' ? -amount : amount,
        Categoria: formData.category,
        Data: formData.date,
        Intestatario: formData.description,
        tipo: formData.type,
        user: user.id
      });

      if (result.success) {
        setShowTransactionModal(false);
        setFormData({
          description: '',
          amount: '',
          type: 'expense',
          category: 'cibo',
          date: new Date().toISOString().split('T')[0]
        });
        // Non è necessario aggiornare manualmente transactions poiché usePocketBase lo gestirà
      } else {
        alert('Errore nel salvataggio della transazione');
      }
    } else {
      // Usa localStorage
      const newId = transactions.length > 0 
        ? Math.max(...transactions.map(t => t.id)) + 1 
        : 1;
      
      const newTransaction = {
        id: newId,
        description: formData.description.trim(),
        amount: amount,
        type: formData.type,
        category: formData.category,
        date: formData.date || new Date().toISOString().split('T')[0]
      };
      
      setTransactions([newTransaction, ...transactions]);
      setShowTransactionModal(false);
      setFormData({
        description: '',
        amount: '',
        type: 'expense',
        category: 'cibo',
        date: new Date().toISOString().split('T')[0]
      });
    }
  };

  // Gestione submit form carte
  const handleSubmitCarta = async (e) => {
    e.preventDefault();
    
    const limite = cartaFormData.tipo === 'credito' ? parseFloat(cartaFormData.limite) : null;
    const saldo = parseFloat(cartaFormData.saldo) || 0;
    
    if (!cartaFormData.nome.trim()) {
      alert('Inserisci un nome per la carta');
      return;
    }
    
    if (cartaFormData.tipo === 'credito' && (!limite || limite <= 0)) {
      alert('Per le carte di credito è necessario un limite valido');
      return;
    }
    
    if (isAuthenticated) {
      // Usa PocketBase
      const result = await pbCreateCard({
        nome: cartaFormData.nome.trim(),
        tipo: cartaFormData.tipo,
        numero: cartaFormData.numero ? cartaFormData.numero.replace(/\s/g, '').slice(-4).padStart(4, '*').padStart(16, '*') : '**** 1234',
        scadenza: cartaFormData.scadenza || '12/25',
        limite: limite,
        saldo: saldo,
        spesaMensile: 0,
        colore: cartaFormData.colore || '#6a11cb',
        icona: cartaFormData.icona || '💳',
        user: user.id
      });

      if (result.success) {
        setShowCartaModal(false);
        setCartaFormData({
          nome: '',
          tipo: 'debito',
          numero: '',
          scadenza: '',
          limite: '',
          saldo: '',
          colore: '#6a11cb',
          icona: '💳'
        });
      }
    } else {
      // Usa localStorage
      const nuovaCarta = {
        id: carte.length > 0 ? Math.max(...carte.map(c => c.id)) + 1 : 1,
        nome: cartaFormData.nome.trim(),
        tipo: cartaFormData.tipo,
        numero: cartaFormData.numero ? cartaFormData.numero.replace(/\s/g, '').slice(-4).padStart(4, '*').padStart(16, '*') : '**** 1234',
        scadenza: cartaFormData.scadenza || '12/25',
        limite: limite,
        saldo: saldo,
        spesaMensile: 0,
        colore: cartaFormData.colore || '#6a11cb',
        icona: cartaFormData.icona || '💳'
      };
      
      setCarte([...carte, nuovaCarta]);
      setShowCartaModal(false);
      setCartaFormData({
        nome: '',
        tipo: 'debito',
        numero: '',
        scadenza: '',
        limite: '',
        saldo: '',
        colore: '#6a11cb',
        icona: '💳'
      });
    }
  };

  // Rimuovi una carta
  const rimuoviCarta = async (id) => {
    if (!window.confirm('Sei sicuro di voler rimuovere questa carta?')) {
      return;
    }

    if (isAuthenticated) {
      // Usa PocketBase
      const result = await pbDeleteCard(id);
      if (!result.success) {
        alert('Errore nella rimozione della carta');
      }
    } else {
      // Usa localStorage
      setCarte(carte.filter(carta => carta.id !== id));
    }
  };

  // Calcola la percentuale di utilizzo per le carte di credito
  const calcolaPercentualeUtilizzo = (carta) => {
    if (carta.tipo !== 'credito' || !carta.limite || carta.limite <= 0) return 0;
    const utilizzato = carta.limite - carta.saldo;
    return Math.round((utilizzato / carta.limite) * 100);
  };

  // Transazioni recenti (ultime 5)
  const transazioniDaUsare = isAuthenticated && pbTransactions.length > 0 ? pbTransactions : transactions;
  const recentTransactions = [...transazioniDaUsare]
    .sort((a, b) => new Date(b.date || b.Data) - new Date(a.date || a.Data))
    .slice(0, 5);

  // Calcola le categorie principali
  const categoryTotals = {};
  transazioniDaUsare.forEach(transaction => {
    const isExpense = transaction.type === 'expense' || (transaction.Importo && transaction.Importo < 0);
    if (isExpense) {
      const category = transaction.category || transaction.Categoria || 'altro';
      const amount = transaction.amount || Math.abs(transaction.Importo) || 0;
      
      if (!categoryTotals[category]) {
        categoryTotals[category] = 0;
      }
      categoryTotals[category] += amount;
    }
  });

  // Top 4 categorie
  const topCategories = Object.entries(categoryTotals)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4);

  const displayCategories = topCategories.length > 0 
    ? topCategories 
    : [['cibo', 0], ['trasporti', 0], ['casa', 0], ['svago', 0]];

  const totals = calculateTotals();
  const cardStats = calculateCardStats();

  // Funzioni per le azioni rapide
  const handleReportClick = () => {
    setActiveView('report');
  };

  const handleCarteClick = () => {
    setActiveView('carte');
  };

  const handleObiettiviClick = () => {
    setActiveView('obiettivi');
  };

  const handleImpostazioniClick = () => {
    setActiveView('impostazioni');
  };

  const handleHomeClick = () => {
    setActiveView('home');
  };

  // Vista Home
  const renderHomeView = () => {
    return (
      <main className="app-main">
        {/* Banner autenticazione */}
        {!isAuthenticated && (
          <div className="auth-banner" onClick={() => setShowAuthModal(true)}>
            <div className="auth-banner-content">
              <div className="auth-banner-icon">🔒</div>
              <div className="auth-banner-text">
                <h4>Sincronizza i tuoi dati</h4>
                <p>Accedi per salvare le tue transazioni nel cloud</p>
              </div>
              <button className="auth-banner-btn">Accedi / Registrati</button>
            </div>
          </div>
        )}

        {/* Info utente */}
        {isAuthenticated && user && (
          <div className="user-info">
            <div className="user-avatar-small">
              {user.avatar ? (
                <img src={user.avatar} alt={user.name} />
              ) : (
                <div className="avatar-placeholder">
                  {user.name ? user.name.charAt(0).toUpperCase() : user.email.charAt(0).toUpperCase()}
                </div>
              )}
            </div>
            <div className="user-details">
              <div className="user-name">{user.name || user.email}</div>
              <button className="logout-btn" onClick={logout}>Esci</button>
            </div>
          </div>
        )}

        {/* Categorie principali */}
        <section className="section">
          <div className="section-header">
            <h2>Categorie principali</h2>
            <button className="view-all">Vedi tutte</button>
          </div>
          <div className="categories-container">
            {displayCategories.map(([catKey, amount]) => {
              const category = categories[catKey] || categories.altro;
              return (
                <div className="category-card" key={catKey}>
                  <div className="category-icon" style={{ color: category.color }}>
                    {category.icon}
                  </div>
                  <div className="category-details">
                    <div className="category-name">{category.name}</div>
                    <div className="category-amount">{formatCurrency(amount)}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
        
        {/* Transazioni recenti */}
        <section className="section">
          <div className="section-header">
            <h2>Transazioni recenti</h2>
            <button className="view-all">Vedi tutte</button>
          </div>
          <div className="transactions-list">
            {recentTransactions.length === 0 ? (
              <div className="no-transactions">Nessuna transazione recente</div>
            ) : (
              recentTransactions.map(transaction => {
                const category = categories[transaction.category || transaction.Categoria] || categories.altro;
                const isIncome = transaction.type === 'income' || (transaction.Importo && transaction.Importo > 0);
                
                return (
                  <div className="transaction-item" key={transaction.id}>
                    <div 
                      className="transaction-icon" 
                      style={{ 
                        backgroundColor: `${category.color}20`, 
                        color: category.color 
                      }}
                    >
                      {category.icon}
                    </div>
                    <div className="transaction-details">
                      <div className="transaction-description">
                        {transaction.description || transaction.Intestatario}
                      </div>
                      <div className="transaction-date">
                        {formatDate(transaction.date || transaction.Data)}
                      </div>
                    </div>
                    <div className={`transaction-amount ${isIncome ? 'income' : 'expense'}`}>
                      {isIncome ? '+' : '-'}{formatCurrency(Math.abs(transaction.amount || transaction.Importo))}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </section>
      </main>
    );
  };

  // Vista Carte
  const renderCarteView = () => {
    return (
      <main className="app-main">
        {/* Header sezione carte */}
        <div className="section-header" style={{ marginBottom: '20px' }}>
          <h2>Le tue Carte</h2>
          <button className="view-all" onClick={() => setShowCartaModal(true)}>
            + Aggiungi Carta
          </button>
        </div>
        
        {/* Lista carte */}
        <div style={{ padding: '0 20px' }}>
          {carte.length === 0 ? (
            <div className="no-transactions" style={{ textAlign: 'center', padding: '40px 20px' }}>
              <div style={{ fontSize: '3rem', marginBottom: '20px' }}>💳</div>
              <p>Nessuna carta aggiunta</p>
              <button 
                className="btn-primary" 
                onClick={() => setShowCartaModal(true)}
                style={{ marginTop: '20px', padding: '12px 24px' }}
              >
                Aggiungi la tua prima carta
              </button>
            </div>
          ) : (
            carte.map(carta => {
              const percentualeUtilizzo = calcolaPercentualeUtilizzo(carta);
              const isCredito = carta.tipo === 'credito';
              
              return (
                <div 
                  key={carta.id}
                  style={{
                    background: `linear-gradient(135deg, ${carta.colore} 0%, ${carta.colore}99 100%)`,
                    color: 'white',
                    borderRadius: '20px',
                    padding: '25px',
                    marginBottom: '20px',
                    boxShadow: '0 10px 20px rgba(0,0,0,0.1)'
                  }}
                >
                  <div style={{ 
                    display: 'flex', 
                    justifyContent: 'space-between', 
                    alignItems: 'flex-start',
                    marginBottom: '30px'
                  }}>
                    <div>
                      <div style={{ fontSize: '1.8rem', marginBottom: '10px' }}>
                        {carta.icona}
                      </div>
                      <h3 style={{ margin: '0 0 5px 0', fontSize: '1.4rem' }}>
                        {carta.nome}
                      </h3>
                      <div style={{ opacity: 0.9, fontSize: '0.9rem' }}>
                        {isCredito ? 'Carta di Credito' : 'Carta di Debito'}
                      </div>
                    </div>
                    
                    <button 
                      onClick={() => rimuoviCarta(carta.id)}
                      style={{
                        background: 'rgba(255,255,255,0.2)',
                        border: 'none',
                        color: 'white',
                        width: '40px',
                        height: '40px',
                        borderRadius: '50%',
                        cursor: 'pointer',
                        fontSize: '1.2rem'
                      }}
                    >
                      ×
                    </button>
                  </div>
                  
                  <div style={{ marginBottom: '25px' }}>
                    <div style={{ 
                      fontSize: '1.6rem', 
                      letterSpacing: '2px',
                      marginBottom: '5px'
                    }}>
                      {carta.numero}
                    </div>
                    <div style={{ fontSize: '0.9rem', opacity: 0.8 }}>
                      Scadenza: {carta.scadenza}
                    </div>
                  </div>
                  
                  <div style={{ 
                    display: 'flex', 
                    justifyContent: 'space-between',
                    marginBottom: '15px'
                  }}>
                    <div>
                      <div style={{ fontSize: '0.85rem', opacity: 0.8 }}>
                        {isCredito ? 'Limite' : 'Saldo'}
                      </div>
                      <div style={{ fontSize: '1.3rem', fontWeight: '600' }}>
                        {isCredito ? formatCurrency(carta.limite) : formatCurrency(carta.saldo)}
                      </div>
                    </div>
                    
                    <div>
                      <div style={{ fontSize: '0.85rem', opacity: 0.8 }}>
                        {isCredito ? 'Disponibile' : 'Spesa Mensile'}
                      </div>
                      <div style={{ fontSize: '1.3rem', fontWeight: '600' }}>
                        {isCredito ? formatCurrency(carta.saldo) : formatCurrency(carta.spesaMensile)}
                      </div>
                    </div>
                  </div>
                  
                  {isCredito && (
                    <div>
                      <div style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        marginBottom: '5px',
                        fontSize: '0.85rem'
                      }}>
                        <span>Utilizzo</span>
                        <span>{percentualeUtilizzo}%</span>
                      </div>
                      <div style={{
                        height: '6px',
                        background: 'rgba(255,255,255,0.2)',
                        borderRadius: '3px',
                        overflow: 'hidden'
                      }}>
                        <div style={{
                          height: '100%',
                          width: `${Math.min(percentualeUtilizzo, 100)}%`,
                          background: 'white',
                          borderRadius: '3px'
                        }}></div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </main>
    );
  };

  // Vista Report
  const renderReportView = () => {
    // Calcola statistiche per il report
    const oggi = new Date();
    const inizioMese = new Date(oggi.getFullYear(), oggi.getMonth(), 1);
    
    const transazioniDaUsare = isAuthenticated && pbTransactions.length > 0 ? pbTransactions : transactions;
    const transazioniMese = transazioniDaUsare.filter(t => {
      const dataTransazione = new Date(t.date || t.Data);
      return dataTransazione >= inizioMese;
    });

    const entrateMese = transazioniMese
      .filter(t => t.type === 'income' || (t.Importo && t.Importo > 0))
      .reduce((sum, t) => sum + (t.amount || Math.abs(t.Importo) || 0), 0);

    const usciteMese = transazioniMese
      .filter(t => t.type === 'expense' || (t.Importo && t.Importo < 0))
      .reduce((sum, t) => sum + (t.amount || Math.abs(t.Importo) || 0), 0);

    // Calcola spese per categoria questo mese
    const categorieMese = {};
    transazioniMese
      .filter(t => t.type === 'expense' || (t.Importo && t.Importo < 0))
      .forEach(t => {
        const categoria = t.category || t.Categoria || 'altro';
        if (!categorieMese[categoria]) {
          categorieMese[categoria] = 0;
        }
        categorieMese[categoria] += t.amount || Math.abs(t.Importo) || 0;
      });

    return (
      <main className="app-main">
        <section className="section">
          <div className="section-header">
            <h2>Report Mensile</h2>
          </div>
          
          <div className="categories-container">
            <div className="category-card">
              <div className="category-icon" style={{ color: '#4CD964' }}>
                📈
              </div>
              <div className="category-details">
                <div className="category-name">Entrate Mese</div>
                <div className="category-amount">{formatCurrency(entrateMese)}</div>
              </div>
            </div>
            
            <div className="category-card">
              <div className="category-icon" style={{ color: '#FF3B30' }}>
                📉
              </div>
              <div className="category-details">
                <div className="category-name">Uscite Mese</div>
                <div className="category-amount">{formatCurrency(usciteMese)}</div>
              </div>
            </div>
            
            <div className="category-card">
              <div className="category-icon" style={{ color: '#6a11cb' }}>
                💰
              </div>
              <div className="category-details">
                <div className="category-name">Saldo Mese</div>
                <div className="category-amount">{formatCurrency(entrateMese - usciteMese)}</div>
              </div>
            </div>
            
            <div className="category-card">
              <div className="category-icon" style={{ color: '#FF9F43' }}>
                📊
              </div>
              <div className="category-details">
                <div className="category-name">Transazioni</div>
                <div className="category-amount">{transazioniMese.length}</div>
              </div>
            </div>
          </div>
        </section>

        <section className="section">
          <div className="section-header">
            <h2>Distribuzione Spese</h2>
          </div>
          
          <div className="transactions-list">
            {Object.entries(categorieMese).length === 0 ? (
              <div className="no-transactions">Nessuna spesa questo mese</div>
            ) : (
              Object.entries(categorieMese)
                .sort(([,a], [,b]) => b - a)
                .map(([categoria, importo]) => {
                  const category = categories[categoria] || categories.altro;
                  const percentuale = usciteMese > 0 
                    ? ((importo / usciteMese) * 100).toFixed(1)
                    : 0;
                  
                  return (
                    <div key={categoria} className="transaction-item">
                      <div className="transaction-icon" style={{ backgroundColor: `${category.color}20`, color: category.color }}>
                        {category.icon}
                      </div>
                      <div className="transaction-details">
                        <div className="transaction-description">{category.name}</div>
                        <div className="transaction-date">{percentuale}% del totale</div>
                      </div>
                      <div className="transaction-amount expense">
                        {formatCurrency(importo)}
                      </div>
                    </div>
                  );
                })
            )}
          </div>
        </section>
      </main>
    );
  };

  // Vista Obiettivi
  const renderObiettiviView = () => {
    return (
      <main className="app-main">
        <section className="section">
          <div className="section-header">
            <h2>I miei Obiettivi</h2>
            <button className="view-all" onClick={() => alert('Nuovo obiettivo')}>
              + Nuovo Obiettivo
            </button>
          </div>
          <div className="no-transactions" style={{ textAlign: 'center', padding: '40px 20px' }}>
            <div style={{ fontSize: '3rem', marginBottom: '20px' }}>🎯</div>
            <p>Gestione Obiettivi</p>
            <p style={{ fontSize: '0.9rem', color: '#666', marginTop: '10px' }}>
              Imposta e monitora i tuoi obiettivi finanziari
            </p>
            <button 
              className="btn-primary" 
              onClick={() => alert('Funzionalità obiettivi')}
              style={{ marginTop: '20px', padding: '12px 24px' }}
            >
              Imposta Obiettivo
            </button>
          </div>
        </section>
      </main>
    );
  };

  // Vista Impostazioni
  const renderImpostazioniView = () => {
    return (
      <main className="app-main">
        <section className="section">
          <div className="section-header">
            <h2>Impostazioni</h2>
          </div>
          <div className="transactions-list">
            <div className="transaction-item" onClick={() => alert('Modifica profilo')}>
              <div className="transaction-icon" style={{ backgroundColor: '#6a11cb20', color: '#6a11cb' }}>
                👤
              </div>
              <div className="transaction-details">
                <div className="transaction-description">Profilo</div>
                <div className="transaction-date">Gestisci il tuo profilo</div>
              </div>
              <div className="transaction-amount">›</div>
            </div>
            
            <div className="transaction-item" onClick={() => alert('Notifiche')}>
              <div className="transaction-icon" style={{ backgroundColor: '#4CD96420', color: '#4CD964' }}>
                🔔
              </div>
              <div className="transaction-details">
                <div className="transaction-description">Notifiche</div>
                <div className="transaction-date">Gestisci le notifiche</div>
              </div>
              <div className="transaction-amount">›</div>
            </div>
            
            <div className="transaction-item" onClick={() => alert('Backup dati')}>
              <div className="transaction-icon" style={{ backgroundColor: '#2575fc20', color: '#2575fc' }}>
                💾
              </div>
              <div className="transaction-details">
                <div className="transaction-description">Backup Dati</div>
                <div className="transaction-date">Salva e ripristina i dati</div>
              </div>
              <div className="transaction-amount">›</div>
            </div>
            
            <div className="transaction-item" onClick={() => {
              if (window.confirm('Vuoi cancellare tutti i dati?')) {
                localStorage.clear();
                setTransactions(getDefaultTransactions());
                setCarte(getDefaultCarte());
                alert('Dati cancellati!');
              }
            }}>
              <div className="transaction-icon" style={{ backgroundColor: '#FF3B3020', color: '#FF3B30' }}>
                🗑️
              </div>
              <div className="transaction-details">
                <div className="transaction-description">Cancella Dati</div>
                <div className="transaction-date">Elimina tutti i dati</div>
              </div>
              <div className="transaction-amount">›</div>
            </div>
          </div>
        </section>
      </main>
    );
  };

  // Renderizza la vista attiva
  const renderView = () => {
    switch(activeView) {
      case 'carte':
        return renderCarteView();
      case 'report':
        return renderReportView();
      case 'obiettivi':
        return renderObiettiviView();
      case 'impostazioni':
        return renderImpostazioniView();
      default:
        return renderHomeView();
    }
  };

  return (
    <div className="app">
      {/* Header */}
      <header className="app-header">
        <div className="header-top">
          <h1>Budget Tracker {isAuthenticated ? `- ${user?.name?.split(' ')[0] || 'Utente'}` : ''}</h1>
          <div className="user-avatar" onClick={() => isAuthenticated ? logout() : setShowAuthModal(true)}>
            {isAuthenticated && user ? (
              <>
                {user.avatar ? (
                  <img src={user.avatar} alt={user.name} className="avatar-icon" />
                ) : (
                  <div className="avatar-icon">
                    {user.name ? user.name.charAt(0).toUpperCase() : user.email.charAt(0).toUpperCase()}
                  </div>
                )}
              </>
            ) : (
              <div className="avatar-icon">👤</div>
            )}
          </div>
        </div>
        
        {/* Saldo - Mostra saldo carte se siamo in vista carte */}
        <div className="balance-container">
          <div className="balance-label">
            {activeView === 'carte' ? 'Saldo Totale Carte' : 'Saldo totale'}
          </div>
          <div className="balance-amount">
            {activeView === 'carte' ? formatCurrency(cardStats.saldoTotale) : formatCurrency(totals.balance)}
          </div>
          
          <div className="balance-details">
            {activeView === 'carte' ? (
              <>
                <div className="balance-item">
                  <div className="balance-item-label">Spesa Mensile</div>
                  <div className="balance-item-amount expense">{formatCurrency(cardStats.spesaTotale)}</div>
                </div>
                <div className="balance-item">
                  <div className="balance-item-label">Carte Attive</div>
                  <div className="balance-item-amount" style={{ color: '#6a11cb' }}>
                    {cardStats.carteAttive}
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="balance-item">
                  <div className="balance-item-label">Entrate</div>
                  <div className="balance-item-amount income">{formatCurrency(totals.income)}</div>
                </div>
                <div className="balance-item">
                  <div className="balance-item-label">Uscite</div>
                  <div className="balance-item-amount expense">{formatCurrency(totals.expense)}</div>
                </div>
              </>
            )}
          </div>
        </div>
        
        {/* Azioni rapide */}
        <div className="quick-actions">
          <button 
            className="action-btn" 
            onClick={handleReportClick}
            style={{ background: activeView === 'report' ? 'rgba(255,255,255,0.25)' : 'rgba(255,255,255,0.15)' }}
          >
            <div className="action-icon">📊</div>
            <span>Report</span>
          </button>
          <button 
            className="action-btn" 
            onClick={handleCarteClick}
            style={{ background: activeView === 'carte' ? 'rgba(255,255,255,0.25)' : 'rgba(255,255,255,0.15)' }}
          >
            <div className="action-icon">💳</div>
            <span>Carte</span>
          </button>
          <button 
            className="action-btn" 
            onClick={handleObiettiviClick}
            style={{ background: activeView === 'obiettivi' ? 'rgba(255,255,255,0.25)' : 'rgba(255,255,255,0.15)' }}
          >
            <div className="action-icon">🎯</div>
            <span>Obiettivi</span>
          </button>
          <button 
            className="action-btn" 
            onClick={handleImpostazioniClick}
            style={{ background: activeView === 'impostazioni' ? 'rgba(255,255,255,0.25)' : 'rgba(255,255,255,0.15)' }}
          >
            <div className="action-icon">⚙️</div>
            <span>Impost.</span>
          </button>
        </div>
      </header>
      
      {/* Contenuto principale in base alla vista */}
      {renderView()}
      
      {/* Footer e navigazione */}
      <footer className="app-footer">
        <nav className="bottom-nav">
          <button 
            className={`nav-item ${activeView === 'home' ? 'active' : ''}`}
            onClick={handleHomeClick}
          >
            <div className="nav-icon">🏠</div>
            <span>Home</span>
          </button>
          <button 
            className={`nav-item ${activeView === 'report' ? 'active' : ''}`}
            onClick={handleReportClick}
          >
            <div className="nav-icon">📊</div>
            <span>Statistiche</span>
          </button>
          
          <button className="add-transaction-btn" onClick={() => setShowTransactionModal(true)}>
            <div className="nav-icon-add">+</div>
          </button>
          
          <button 
            className={`nav-item ${activeView === 'obiettivi' ? 'active' : ''}`}
            onClick={handleObiettiviClick}
          >
            <div className="nav-icon">🎯</div>
            <span>Obiettivi</span>
          </button>
          <button 
            className={`nav-item ${activeView === 'impostazioni' ? 'active' : ''}`}
            onClick={handleImpostazioniClick}
          >
            <div className="nav-icon">👤</div>
            <span>Profilo</span>
          </button>
        </nav>
      </footer>
      
      {/* Modal per aggiungere transazioni */}
      {showTransactionModal && (
        <div className="modal">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Aggiungi transazione</h3>
              <button className="close-modal" onClick={() => setShowTransactionModal(false)}>
                &times;
              </button>
            </div>
            
            <form onSubmit={handleSubmitTransaction}>
              <div className="form-group">
                <label htmlFor="description">Descrizione</label>
                <input 
                  type="text" 
                  id="description" 
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  placeholder="Es. Cena al ristorante" 
                  required
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="amount">Importo (€)</label>
                <input 
                  type="number" 
                  id="amount" 
                  name="amount"
                  value={formData.amount}
                  onChange={handleInputChange}
                  step="0.01"
                  min="0.01"
                  required
                />
              </div>
              
              <div className="form-group">
                <label>Tipo</label>
                <div className="type-selector">
                  <button 
                    type="button" 
                    className={`type-btn ${formData.type === 'expense' ? 'active' : ''}`}
                    onClick={() => setFormData(prev => ({ ...prev, type: 'expense' }))}
                  >
                    Uscita
                  </button>
                  <button 
                    type="button" 
                    className={`type-btn ${formData.type === 'income' ? 'active' : ''}`}
                    onClick={() => setFormData(prev => ({ ...prev, type: 'income' }))}
                  >
                    Entrata
                  </button>
                </div>
              </div>
              
              <div className="form-group">
                <label htmlFor="category">Categoria</label>
                <select 
                  id="category" 
                  name="category"
                  value={formData.category}
                  onChange={handleInputChange}
                  required
                >
                  {Object.entries(categories).map(([key, cat]) => (
                    <option key={key} value={key}>
                      {cat.name} {cat.icon}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="form-group">
                <label htmlFor="date">Data</label>
                <input 
                  type="date" 
                  id="date" 
                  name="date"
                  value={formData.date}
                  onChange={handleInputChange}
                />
              </div>
              
              <div className="form-actions">
                <button 
                  type="button" 
                  className="btn-secondary" 
                  onClick={() => setShowTransactionModal(false)}
                >
                  Annulla
                </button>
                <button type="submit" className="btn-primary">
                  Aggiungi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      
      {/* Modal per aggiungere carte */}
      {showCartaModal && (
        <div className="modal">
          <div className="modal-content">
            <div className="modal-header">
              <h3>Aggiungi Nuova Carta</h3>
              <button className="close-modal" onClick={() => setShowCartaModal(false)}>
                &times;
              </button>
            </div>
            
            <form onSubmit={handleSubmitCarta}>
              <div className="form-group">
                <label htmlFor="nome">Nome Carta</label>
                <input 
                  type="text" 
                  id="nome" 
                  name="nome"
                  value={cartaFormData.nome}
                  onChange={handleCartaInputChange}
                  placeholder="Es. Carta Principale" 
                  required
                />
              </div>
              
              <div className="form-group">
                <label>Tipo Carta</label>
                <div className="type-selector">
                  <button 
                    type="button" 
                    className={`type-btn ${cartaFormData.tipo === 'debito' ? 'active' : ''}`}
                    onClick={() => setCartaFormData(prev => ({ ...prev, tipo: 'debito' }))}
                  >
                    Debito
                  </button>
                  <button 
                    type="button" 
                    className={`type-btn ${cartaFormData.tipo === 'credito' ? 'active' : ''}`}
                    onClick={() => setCartaFormData(prev => ({ ...prev, tipo: 'credito' }))}
                  >
                    Credito
                  </button>
                </div>
              </div>
              
              {cartaFormData.tipo === 'credito' && (
                <div className="form-group">
                  <label htmlFor="limite">Limite di Credito (€)</label>
                  <input 
                    type="number" 
                    id="limite" 
                    name="limite"
                    value={cartaFormData.limite}
                    onChange={handleCartaInputChange}
                    step="0.01" 
                    min="0.01" 
                    placeholder="5000.00" 
                    required={cartaFormData.tipo === 'credito'}
                  />
                </div>
              )}
              
              <div className="form-group">
                <label htmlFor="saldo">
                  {cartaFormData.tipo === 'credito' ? 'Saldo Attuale (€)' : 'Saldo Carta (€)'}
                </label>
                <input 
                  type="number" 
                  id="saldo" 
                  name="saldo"
                  value={cartaFormData.saldo}
                  onChange={handleCartaInputChange}
                  step="0.01" 
                  placeholder="0.00" 
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="numero">Ultime 4 cifre (opzionale)</label>
                <input 
                  type="text" 
                  id="numero" 
                  name="numero"
                  value={cartaFormData.numero}
                  onChange={handleCartaInputChange}
                  placeholder="1234" 
                  maxLength="4"
                  pattern="[0-9]{4}"
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="scadenza">Scadenza (MM/YY)</label>
                <input 
                  type="text" 
                  id="scadenza" 
                  name="scadenza"
                  value={cartaFormData.scadenza}
                  onChange={handleCartaInputChange}
                  placeholder="12/25" 
                  maxLength="5"
                />
              </div>
              
              <div className="form-group">
                <label>Icona Carta</label>
                <div style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '10px',
                  marginTop: '10px'
                }}>
                  {iconeCarte.map((icon, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => handleIconChange(icon.icona)}
                      style={{
                        background: cartaFormData.icona === icon.icona ? cartaFormData.colore : '#f0f0f0',
                        color: cartaFormData.icona === icon.icona ? 'white' : '#333',
                        border: 'none',
                        borderRadius: '10px',
                        width: '50px',
                        height: '50px',
                        fontSize: '1.5rem',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}
                      title={icon.nome}
                    >
                      {icon.icona}
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="form-group">
                <label>Colore Carta</label>
                <div style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: '10px',
                  marginTop: '10px'
                }}>
                  {coloriCarte.map((colore, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => handleColorChange(colore.valore)}
                      style={{
                        background: colore.valore,
                        border: `3px solid ${cartaFormData.colore === colore.valore ? 'white' : colore.valore}`,
                        borderRadius: '50%',
                        width: '40px',
                        height: '40px',
                        cursor: 'pointer',
                        boxShadow: cartaFormData.colore === colore.valore ? '0 0 0 2px #6a11cb' : 'none'
                      }}
                      title={colore.nome}
                    />
                  ))}
                </div>
              </div>
              
              <div className="form-actions">
                <button 
                  type="button" 
                  className="btn-secondary" 
                  onClick={() => setShowCartaModal(false)}
                >
                  Annulla
                </button>
                <button type="submit" className="btn-primary">
                  Aggiungi Carta
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      
      {/* Modal autenticazione */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onSuccess={() => {
          console.log('Autenticazione riuscita');
        }}
      />
    </div>
  );
}

export default App;